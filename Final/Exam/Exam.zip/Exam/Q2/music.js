/* This psuedocode is provided just to help you. 
You can implement it using your way as well
Psuedocode for defining the function:  
1. Access the audio element on the web page with its ID and store it in a variable .
2. Set the current playback time of the variable's audio element to 0 second using .currentTime=0.
    This sets the currentTime property of variable to 0, which rewinds the audio to the start.
3. Play the audio element using play (.play() )function.
4. Test it and then implement other functions the same way. 
*/


function fun3(){
    note_c = document.getElementById('c');
    RemotePlayback(note_c)
}

function fun4(){
    note_d = document.getElementById('d')
}

function fun5(){
    note_e = document.getElementById('e')
}

function fun6(){
    note_f = document.getElementById('f')
}

function fun7(){
    note_g = document.getElementById('g')
}

function fun1(){
    note_a = document.getElementById('a')
}

function fun2(){
    note_b = document.getElementById('b')
}

